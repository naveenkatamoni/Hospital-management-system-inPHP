<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/login.php">
<title>Login | Admin</title>
<script language="javascript">
    window.location.href = "pages/login.php"
</script>
</head>
<body>
Go to <a href="pages/index.html">/pages/login.php</a>
</body>
</html>
