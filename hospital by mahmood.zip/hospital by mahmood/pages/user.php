<?php 
include_once 'connection.php';

$query="select * from user";
 ?>