<?php

$username="root";
$password="";
$host="localhost";
$database="truecare";
   
$conn=mysqli_connect("$host","$username","$password","$database") or die("Server Error");

?>