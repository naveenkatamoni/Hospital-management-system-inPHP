just import the truecare.sql
see the admin password there and then login
